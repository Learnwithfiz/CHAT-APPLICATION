-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 26, 2023 at 09:18 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatbox`
--

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

DROP TABLE IF EXISTS `msg`;
CREATE TABLE IF NOT EXISTS `msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_data` varchar(200) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `user_id_to` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `msg`
--

INSERT INTO `msg` (`id`, `msg_data`, `user_id`, `user_id_to`, `status`) VALUES
(16, 'hi wasy', '1', '2', '1'),
(17, 'hi wasy', '1', '2', '1'),
(18, 'hello i am fiz', '1', '2', '1'),
(19, 'hello', '2', '1', '1'),
(15, 'hello fiz', '2', '1', '1'),
(20, 'helllo', '1', '2', '1'),
(21, 'asif eseche', '2', '1', '1'),
(22, 'asif jassena', '1', '2', '1'),
(23, 'movemant bill dissena', '1', '2', '1'),
(24, 'gulsana', '1', '2', '1'),
(25, 'ami office', '2', '1', '1'),
(26, 'hi fiz, am antu', '3', '1', '1'),
(27, 'hi , wasy i am antu', '3', '2', '1'),
(28, 'hi antu vai ..how are u?', '2', '3', '1'),
(29, 'i am ok', '3', '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE IF NOT EXISTS `register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `email`, `phone`, `img`, `pass`, `status`) VALUES
(1, 'fiz', 'fiz@gmail.com', '0171828', 'IMG_20221023_105401.jpg', '123', 1),
(2, 'wasy', 'wasy@gmail.com', '2092', 'Report.png', '1234', 1),
(3, 'antu', 'antu@gmail.com', '01882', 'Screenshot (2).png', '123', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

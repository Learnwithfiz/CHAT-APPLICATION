<?php
session_start();
$con = mysqli_connect("localhost","root","","chatbox");
if($_SESSION['email']==true)
{
  //  echo $_SESSION['email'];
}else{
    header("location:login.php");
}
$user_id = $_SESSION['id'];
$user_id_to_data = $_GET['user_id_to_data'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        div{
          
        }
        .display{
          
            width:220px;
            height:300px;
            background:cyan;
            box-shadow:5px 5px  10px white ;
            border:1px solid gray;
            overflow-y:scroll;
        }
        #msg{
            position: relative;
            top:300px;
            width:200px;
            padding:10px
        }
        #send{
            position: relative;
            top:270px;
            width:20px;
            left:200px;
            background:blue;
            color:white;
            padding:10px;
            border-radius:10px;
            cursor:pointer;
        }
        .main{
            position: relative;
            left:1200px;
        }
        #res{
            overflow-y:scroll;
        }
        .x{
            position: relative;
            top:-320px;
        }
    </style>
</head>
<body>
     <div class="main">
     <form action="">
      <div class="display">
        <p id="res"></p>
       
      </div>

    </form>
     <div class="x">
     <div id="msg_div">
            <input type="text" placeholder="write...." id="msg"name="msg" >
            <input type="hidden" placeholder="write...." value="<?php echo $user_id_to_data ?>" id="user_id_to_data"name="msg" >
        </div>
       <span onclick="ONSubmit()" id="send">send</span> 
     </div>
     </div>
     <script src="index.js"></script>
</body>
</html>
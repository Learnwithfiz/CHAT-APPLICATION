
<?php
$con = mysqli_connect("localhost","root","","chatbox");
if(isset($_POST['submit'])=="POST")
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone =$_POST['phone'];
    $pass=$_POST['pass'];
    $img_name = $_FILES['img']['name'];
    $tmp_name = $_FILES['img']['tmp_name'];
    
    $upload = move_uploaded_file($tmp_name, "upload/" . $img_name);
    if($upload){
        $in = "INSERT INTO register(name,email,phone,img,pass,status)
        values('$name','$email','$phone','$img_name','$pass',1)";
       // echo $in;
        $ex = mysqli_query($con,$in);
        if($ex)
        {
            echo "success";
        }else{
            echo "failed";
        }
    }else{
        echo "failed not update";
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post" enctype="multipart/form-data" action="">
        <input type="text" name="name" id="name" placeholder="name"> <br>
        <input type="file" name="img">
        <input type="text" name="email" id="email" placeholder="email"> <br>
        <input type="text"name="phone" id="phone" placeholder="phone"> <br>
        <input type="password"name="pass" id="pass" placeholder="pass">
        <button name="submit">Register</button>
    </form>
     
    <a href="login.php">login</a>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="index.js"></script>
</body>
</html>
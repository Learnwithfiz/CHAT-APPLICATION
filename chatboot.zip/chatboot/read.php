<?php
session_start();
$con = mysqli_connect("localhost","root","","chatbox");
if($_SESSION['email']==true)
{
    echo $_SESSION['email'];
}else{
    header("location:login.php");
}
$sel = "SELECT * from msg WHERE (user_id = $_GET[user_id] AND user_id_to = $_GET[user_id_to])
OR (user_id = $_GET[user_id_to] AND user_id_to = $_GET[user_id]) order by id asc";
//echo $sel ;
$qu = mysqli_query($con,$sel);
while($row=mysqli_fetch_array($qu)){  
    $messageColor = ($row['user_id'] == $_GET['user_id']) ? 'red;text-align:left;' : 'blue;text-align:right;';
   // $userName = ($row['user_id']==$_GET['user_id']) ? $row['name']
    ?>

       <p style="color: <?php echo $messageColor; ?>"><span></span><?php echo $row['msg_data']; ?></p>
<?php  }
  
 
     
  
?>

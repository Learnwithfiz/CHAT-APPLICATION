<?php
session_start();
$con = mysqli_connect("localhost","root","","chatbox");
if($_SESSION['email']==true)
{
    echo $_SESSION['email'];
}else{
    header("location:login.php");
}
$user_id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #userImg{
            width:40px;
            height:40px;
            border:1px solid green;
            border-radius:50%;
        }
        .user{
            position: relative;
            left:-40px;
            top:5px;
        }
    </style>
</head>
<body>
    <h4>Hello ! choose your fd and start chat </h4>
    <?php 
      $sel ="SELECT * FROM register";
      $ex = mysqli_query($con,$sel );
      while($row=mysqli_fetch_array($ex))
      { ?>
         <td><img onclick="userShow('<?php echo $user_id?>',<?php echo $row['id'] ?>)" id="userImg" src="upload/<?php echo $row['img']; ?>" alt=""></td>
        <span class="user"><?php echo $row['name'] ?></span></td>  
        <input type="hidden" id="user_id" value="<?php echo $user_id ?>"> 
        <input type="hidden"  id="user_id_to" value="<?php echo $row['id'] ?>"> 
     <?php   }
    ?>
<div id="result"></div>
<div id="result2"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="index.js"></script>
</body>
</html>
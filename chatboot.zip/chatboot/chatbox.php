<?php
session_start();
$con = mysqli_connect("localhost","root","","chatbox");
if($_SESSION['email']==true)
{
    echo $_SESSION['email'];
}else{
    header("location:login.php");
}
$user_id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<div id="result"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="index.js"></script>
</body>
</html>
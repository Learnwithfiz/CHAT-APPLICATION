
<?php
$con = mysqli_connect("localhost","root","","chatbox");
session_start();
if(isset($_POST['submit'])=="POST")
{
    
    $email = $_POST['email'];
   
    $pass=$_POST['pass'];
   
    $sel ="SELECT id,email,pass from register WHERE email='$email' and pass='$pass'";
    $ex = mysqli_query($con,$sel);
    $fetch = mysqli_fetch_array($ex);
    if($ex){
        $_SESSION['id'] = $fetch['id'];
        $_SESSION['email'] = $fetch['email'];
        header("location:chat.php");
    }
   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post" enctype="multipart/form-data" action="">
       
      
        <input type="text" name="email" id="email" placeholder="email"> <br>

        <input type="password"name="pass" id="pass" placeholder="pass">
        <button name="submit">login</button>
    </form>
</body>
</html>
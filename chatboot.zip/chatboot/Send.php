<?php
session_start();
$con = mysqli_connect("localhost","root","","chatbox");
if($_SESSION['email']==true)
{
    echo $_SESSION['email'];
}else{
    header("location:login.php");
}
$user_id = $_SESSION['id'];
$ins = "INSERT INTO msg(msg_data,user_id,user_id_to,status)
values('$_POST[msg]','$_POST[user_id]','$_POST[user_id_to]',1)";
$data = mysqli_query($con,$ins);
if($data)
{
    echo "success";
}else{
    echo "failed";
}
?>

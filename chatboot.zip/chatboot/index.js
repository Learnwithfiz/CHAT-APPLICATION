
function userShow(id,user_id_to_data)
{ 
    // alert(id)
    // alert(user_id_to)
    var id = id ;
    var user_id_to_data = user_id_to_data;
    $.ajax({
        method:"GET",
        url:"messenger.php",
        data:{id:id,user_id_to_data:user_id_to_data},
        
        success:function(res)
        {
            $("#result").html(res);
            Read()
        }
    })
}
function ONSubmit(){
  var msg =   $("#msg").val();
  var user_id =   $("#user_id").val();
  var user_id_to =   $("#user_id_to_data").val();
  $.ajax({
    method:"POST",
    url:"Send.php",
    data:{msg:msg,user_id:user_id,user_id_to:user_id_to},
    success:function(res){
      console.log(res);
      Read()
     
    }
  })
}
window.onload=function(){
   
    var user_id =   $("#user_id").val();
    var user_id_to =   $("#user_id_to_data").val();
    $.ajax({
        method:"get",
        url:"read.php",
        data:{user_id:user_id,user_id_to:user_id_to},
        success:function(res)
        {
            $("#res").html(res)
        }
    })
}

setInterval(Read,100);
function Read()
{
    var user_id =   $("#user_id").val();
    var user_id_to =   $("#user_id_to_data").val();
    $.ajax({
        method:"get",
        url:"read.php",
        data:{user_id:user_id,user_id_to:user_id_to},
        success:function(res)
        {
            $("#res").html(res)
        }
    })
}